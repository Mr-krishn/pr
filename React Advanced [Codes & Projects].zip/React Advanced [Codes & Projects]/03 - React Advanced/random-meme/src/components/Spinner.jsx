import React from 'react'

const Spinner = () => {
  return (
    // CSS Loader Generator 
    <div className='spinner'></div>
  )
}

export default Spinner