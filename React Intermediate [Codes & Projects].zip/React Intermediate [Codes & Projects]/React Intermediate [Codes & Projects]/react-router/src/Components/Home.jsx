import React from 'react'
import { Outlet } from 'react-router-dom'

const Home = () => {
  return (
    <div>
      This is my Homepage
    </div>
  )
}

export default Home