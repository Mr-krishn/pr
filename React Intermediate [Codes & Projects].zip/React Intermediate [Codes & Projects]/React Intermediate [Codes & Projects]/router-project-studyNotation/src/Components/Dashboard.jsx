import React from 'react'

const Dashboard = () => {
  return (
    <div className='grid place-items-center text-richblack-100 text-3xl h-full'>Dashboard</div>
  )
}

export default Dashboard