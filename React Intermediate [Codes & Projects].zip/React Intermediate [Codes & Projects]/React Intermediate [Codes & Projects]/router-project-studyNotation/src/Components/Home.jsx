import React from 'react'

const Home = () => {
  return (
    <div className='grid place-items-center text-richblack-100 text-3xl h-full'>Home</div>
  )
}

export default Home