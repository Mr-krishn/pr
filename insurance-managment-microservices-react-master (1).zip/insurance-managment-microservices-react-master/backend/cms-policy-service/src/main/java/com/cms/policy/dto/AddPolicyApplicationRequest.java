package com.cms.policy.dto;

import lombok.Data;

@Data
public class AddPolicyApplicationRequest {

	private Integer policyId;
	
	private Integer customerId;
	
}
