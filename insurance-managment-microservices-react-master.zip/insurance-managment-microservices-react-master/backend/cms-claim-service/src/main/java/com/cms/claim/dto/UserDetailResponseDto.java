package com.cms.claim.dto;

import lombok.Data;

@Data
public class UserDetailResponseDto extends CommonApiResponse {

	private User user;

}
