package com.myorg.one_to_one_unidirectional;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
	
	@Autowired
	private EmployeeRepository employeeRepository;

	@Autowired
    private ComputerRepository computerRepository;

	@PostMapping("/createNew")
	public Employee createNew(@RequestBody Employee employee) {	
		 // Extract the computer ID from the incoming JSON request
        Computer computer = employee.getComputer();
        if (computer != null && computer.getId() != null) {
            // Fetch the existing computer by ID
            Optional<Computer> existingComputer = computerRepository.findById(computer.getId());
            if (existingComputer.isPresent()) {
                // Assign the existing computer to the employee
                employee.setComputer(existingComputer.get());
            } else {
                throw new RuntimeException("Computer with ID " + computer.getId() + " does not exist.");
            }
        }
        // Save the employee along with the associated computer
        return employeeRepository.save(employee);
	}
	
	@GetMapping("/fetchAll")
	public List<Employee> fetchAll(){
		return employeeRepository.findAll();
	}
}
