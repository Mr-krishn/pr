package com.myorg.one_to_one_unidirectional;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OneToOneUnidirectionalApplicationTests {

	@Test
	void contextLoads() {
	}

}
