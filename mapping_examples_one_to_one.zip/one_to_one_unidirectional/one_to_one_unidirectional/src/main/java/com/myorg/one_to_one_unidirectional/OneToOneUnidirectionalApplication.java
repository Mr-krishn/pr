package com.myorg.one_to_one_unidirectional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OneToOneUnidirectionalApplication {

	public static void main(String[] args) {
		SpringApplication.run(OneToOneUnidirectionalApplication.class, args);
	}

}
