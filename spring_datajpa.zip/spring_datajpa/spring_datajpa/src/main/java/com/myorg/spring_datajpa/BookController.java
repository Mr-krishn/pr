package com.myorg.spring_datajpa;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "http://localhost:3001")		//CORS policy
@RestController
@RequestMapping("/book")
public class BookController {

	@Autowired
	private BookService bookService;
	
	@GetMapping(value="/getAll", headers = "Accept=application/json")
	//@GetMapping("/getAll")
	public ResponseEntity<List<Book>> getAllBooks(){
		return new ResponseEntity<>(bookService.findAll(),HttpStatus.OK);
	}
	
	@GetMapping("/getByIsbn")
	public ResponseEntity<Book> getBookByIsbn(@RequestParam Long isbn) {
		Optional<Book>optional=bookService.findByIsbn(isbn);
		return new ResponseEntity<>(optional.orElse(null), HttpStatus.OK);
	}
	
	@PostMapping("/addNew")
	public ResponseEntity<Book> addNewBook(@RequestBody Book book) {
		return new ResponseEntity<>(bookService.save(book),HttpStatus.OK);
	}
	
	@PatchMapping("/revisePrice")
	public void revisePrice(@RequestParam Long isbn, @RequestParam Double revisedPrice) {
		bookService.revisePrice(isbn, revisedPrice);
	}
	
	@DeleteMapping("/delete")
	public void delete(@RequestParam Long isbn) {
		bookService.delete(isbn);
	}
	
	@GetMapping("/getByTitle")
	public ResponseEntity<List<Book>> getByTitle(@RequestParam String title) {
		Optional<List<Book>>optional=bookService.findByTitle(title);
		return new ResponseEntity<>(optional.orElse(null), HttpStatus.OK);
	}
	
	@GetMapping("/getByAuthor")
	public ResponseEntity<List<Book>> getByAuthor(@RequestParam String author) {
		Optional<List<Book>>optional=bookService.findByAuthor(author);
		return new ResponseEntity<>(optional.orElse(null), HttpStatus.OK);
	}
	
	@PatchMapping("/reviseDop")
	public void reviseDop(@RequestParam Long isbn, @RequestParam LocalDate dop) {
		bookService.reviseDop(isbn,dop);
	}
	
	@GetMapping("/getByPrice")
	public ResponseEntity<List<Book>> getByPrice(@RequestParam Double price) {
		Optional<List<Book>>optional=bookService.findByPrice(price);
		return new ResponseEntity<>(optional.orElse(null), HttpStatus.OK);
	}
	
	@GetMapping("/getPaginatedBooks")
	public ResponseEntity<Page<Book>> getPaginatedBooks(
	        @RequestParam(defaultValue = "0") int page,
	        @RequestParam(defaultValue = "5") int size,
	        @RequestParam(defaultValue = "title") String sortBy) {

	    Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy));
	    Page<Book> booksPage = bookService.getPaginated(pageable);
	    return new ResponseEntity<>(booksPage, HttpStatus.OK);
	}
}