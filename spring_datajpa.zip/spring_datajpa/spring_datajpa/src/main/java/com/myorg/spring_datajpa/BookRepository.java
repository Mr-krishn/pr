package com.myorg.spring_datajpa;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jakarta.transaction.Transactional;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {
	
	//JPQL queries
	@Query("select book from Book book where book.title=:book_title")
	Optional<List<Book>> findByTitle(@Param("book_title") String book_title); 	//book_title is named parameter
	
	@Query("select book from Book book where book.author=:book_author")
	Optional<List<Book>> findByAuthor( String book_author); 	
	
	//JPQL with DML
	@Query("update Book book set book.dop = :dop where book.isbn =:isbn")
	@Modifying
	@Transactional
	void updateDop(@Param("isbn") Long isbn, @Param("dop") LocalDate dop);
	
	Optional<List<Book>> findByPrice(@Param("book_price") Double book_price);

}