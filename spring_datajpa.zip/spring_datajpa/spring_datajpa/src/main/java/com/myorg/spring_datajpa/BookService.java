package com.myorg.spring_datajpa;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface BookService {

    List<Book> findAll();  
    Optional<Book> findByIsbn(Long isbn);       
    Book save(Book book);                   
    void delete(Long isbn);
    Optional<List<Book>> findByTitle(String title);       
    Optional<List<Book>> findByAuthor(String author);     
    void revisePrice(Long isbn, Double revisedPrice);  
    void reviseDop(Long isbn, LocalDate newDop);
    Optional<List<Book>> findByPrice(Double price);       
    Page<Book> getPaginated(Pageable pageable);  
}
