package com.myorg.spring_datajpa;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
public class BookServiceImpl implements BookService{
	
	@Autowired
	private BookRepository bookRepository;

	@Override
	public List<Book> findAll() {
		return bookRepository.findAll();
	}

	@Override
	public Optional<Book> findByIsbn(Long isbn) {
		//Optional<Book>optional=bookRepository.findById(isbn);
		return Optional.ofNullable(bookRepository.findById(isbn).orElse(null));
	}

	@Override
	public Book save(Book book) {
		return bookRepository.save(book);
	}

	@Override
	public void revisePrice(Long isbn, Double revisedPrice) {
		Optional<Book>optional=bookRepository.findById(isbn);
		if(optional.isPresent()) {
			Book book=optional.get();
			book.setPrice(revisedPrice);
			bookRepository.save(book);
		}
	}

	@Override
	public void delete(Long isbn) {
		bookRepository.deleteById(isbn);
	}

	@Override
	public Optional<List<Book>> findByTitle(String title) {
		//Optional<Book>optional=bookRepository.findBookByTitle(title);
		return Optional.ofNullable(bookRepository.findByTitle(title).orElse(null));
	}
	
	@Override
	public Optional<List<Book>> findByAuthor(String author) {
		return Optional.ofNullable(bookRepository.findByAuthor(author).orElse(null));
	}

	@Override 
	public void reviseDop(Long isbn, LocalDate newDop) {
		Optional<Book>optional=bookRepository.findById(isbn);
		if(optional.isPresent()) {
			Book book=optional.get();
			book.setDop(newDop);
			bookRepository.save(book);
		}
	}

	@Override
	public Optional<List<Book>> findByPrice(Double price) {
		return Optional.ofNullable(bookRepository.findByPrice(price).orElse(null));
	}

	@Override
    public Page<Book> getPaginated(Pageable pageable) {
        return bookRepository.findAll(pageable);
    }
}